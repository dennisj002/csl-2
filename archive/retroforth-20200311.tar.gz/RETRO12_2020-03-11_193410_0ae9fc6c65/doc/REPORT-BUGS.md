# Reporting Bugs

Bugs can be reported via the IRC channel, by sending me a
message on Mastodon, or via email.

**IRC**

Join #retro on irc.freenode.net. If you ask a question,
please be patient. The channel has large idle times, but is
logged (see forthworks.com/retro/irc-logs) and I generally
try to answer questions in a reasonable time period.

**Mastodon**

@crc@mastodon.social

**email**

crc@forthworks.com
