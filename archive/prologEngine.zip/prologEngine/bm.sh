# ensure *** ANSWERS are not printed in Engine.java -too verbose otherwise
# if you do not have sipl installed rplace go with jgo
go.sh perms
go.sh queens
go.sh lambdas
go.sh sud4x
go.sh mperms
