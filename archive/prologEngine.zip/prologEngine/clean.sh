rm -f progs/*.wam
rm -f progs/*.dyn
rm -f progs/*.hi
rm -f progs/*.hi.nl
rm -f progs/*.hi.pl
rm -f progs/*.nl.pl
rm -f progs/*.cl
rm -f *.class
