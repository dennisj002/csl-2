
int
main()
{
	return 3-3;
}
