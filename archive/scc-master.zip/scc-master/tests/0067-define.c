#define X 6 / 2

int
main()
{
	return X - 3;
}
