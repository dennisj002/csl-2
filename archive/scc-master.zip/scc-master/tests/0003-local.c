

int
main()
{
	int x;
	
	x = 4;
	return x - 4;
}
