// This wouldn't compile

typedef struct  { } Vec;

static void
vecresize(Vec *v, int cap)
{
	return;
}

int main()
{
	return 0;
}
