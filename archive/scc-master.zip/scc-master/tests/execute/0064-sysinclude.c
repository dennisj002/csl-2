#include <0064-sysinclude.h>

int
main()
{
	return x - y;
}
