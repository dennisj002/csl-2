
int
f(int f)
{
	return f;
}

int
main()
{
	return f(0);
}
