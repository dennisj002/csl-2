double x = 100;

int
main()
{
	return x < 1;
}
