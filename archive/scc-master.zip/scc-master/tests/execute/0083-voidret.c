
void
voidfn()
{
    return;
}

int
main()
{
    voidfn();
    return 0;
}
