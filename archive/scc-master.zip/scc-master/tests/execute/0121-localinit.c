main()
{
	int x[] = { 1, 0 };
	return x[1];
}
