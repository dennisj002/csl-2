
typedef int x;

int
main()
{
	x v;
	v = 0;
	return v;
}

