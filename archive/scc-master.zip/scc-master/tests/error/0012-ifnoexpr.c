/*
PATTERN:
0012-ifnoexpr.c:7: error: unexpected '
'
.
*/

#if
#endif

