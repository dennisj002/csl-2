/*
PATTERN:
0003-junkinclude.c:7: error: trailing characters after preprocessor directive
.
*/

#include "0003-junkinclude.c" bar
