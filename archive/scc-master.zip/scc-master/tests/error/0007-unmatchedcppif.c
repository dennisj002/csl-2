/*
PATTERN:

.
*/

#ifdef FOO


