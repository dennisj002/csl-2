/*
PATTERN:

.
*/

#if 1

#else

#elif 0

#endif
