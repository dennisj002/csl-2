/*
PATTERN:

.
*/

int x[2] = {1, 2, 3};
