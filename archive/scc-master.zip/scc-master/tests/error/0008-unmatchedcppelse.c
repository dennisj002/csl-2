/*
PATTERN:
0008-unmatchedcppelse.c:7: error: #else without #ifdef/ifndef
.
*/

#else


