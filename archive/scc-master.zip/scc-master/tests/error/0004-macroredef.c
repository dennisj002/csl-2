/*
PATTERN:
0004-macroredef.c:8: warning: 'X' redefined
.
*/

#define X 1
#define X 2

