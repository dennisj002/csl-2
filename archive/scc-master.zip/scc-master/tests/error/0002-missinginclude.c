/*
PATTERN:
0002-missinginclude.c:7: error: included file 'MISSING.h' not found
.
*/

#include "MISSING.h"
