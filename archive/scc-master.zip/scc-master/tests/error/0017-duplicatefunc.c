/*
PATTERN:
0017-duplicatefunc.c:15: error: redefinition of 'main'
.
*/

int
main()
{
	return 0;
}

int
main()
{
	return 0;
}

