/*
PATTERN:

.
*/

#define X(A, A) 0

