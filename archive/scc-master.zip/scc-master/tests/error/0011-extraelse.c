/*
PATTERN:

.
*/

#if 1

#else

#else

#endif
