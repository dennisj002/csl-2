/*
PATTERN:
0005-fmacro.c:7: error: macro arguments must be identifiers
.
*/

#define X(

