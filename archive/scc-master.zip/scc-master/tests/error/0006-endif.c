/*
PATTERN:
0006-endif.c:7: error: #endif without #if
.
*/

#endif

