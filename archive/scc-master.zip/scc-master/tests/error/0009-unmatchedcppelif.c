/*
PATTERN:

.
*/

#elif 1

