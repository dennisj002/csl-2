/*
PATTERN:
0001-sanity.c:9: error: 'FOO' undeclared
.
*/

int main()
{
	return FOO;
}

