#define FOO 0

int main()
{
	return FOO;
}

