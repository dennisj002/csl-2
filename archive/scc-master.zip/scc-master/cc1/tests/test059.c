/* See LICENSE file for copyright and license details. */

/*
name: TEST059
description: Test of initalizers for strings
error:
TODO
output:

*/

char s0[] = "foo";
char s1[7] = "foo";
char s2[2] = "foo";
char s3[] = {"foo"};
char *p = "foo";
int m[] = "foo";
