#ifndef _STDIO_H
#define _STDIO_H

int printf(const char *fmt, ...);

#endif
