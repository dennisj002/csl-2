/* See LICENSE file for copyright and license details. */
#ifndef _STDBOOL_H
#define _STDBOOL_H

#define bool _Bool
#define true ((bool) 1)
#define false ((bool) 0)
#define __bool_true_false_are_defined 1	

#endif
