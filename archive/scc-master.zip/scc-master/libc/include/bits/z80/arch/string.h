/* See LICENSE file for copyright and license details. */

#ifndef _SIZET
typedef unsigned size_t;
#endif
