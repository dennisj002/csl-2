/* See LICENSE file for copyright and license details. */

#ifndef _SIZET
typedef unsigned size_t;
#define _SIZET
#endif

#define EXIT_FAILURE 1
#define EXIT_SUCCESS 0

#ifndef _WCHAR_T
typedef short wchar_t;
#define _WCHAR_T
#endif

#define _ALIGNTYPE int
