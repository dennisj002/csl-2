/* See LICENSE file for copyright and license details. */

#ifndef _SIZET
typedef unsigned size_t;
#define _SIZET
#endif

typedef long time_t;
