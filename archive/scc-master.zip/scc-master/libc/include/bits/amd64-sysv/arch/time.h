/* See LICENSE file for copyright and license details. */

#ifndef _SIZET
typedef unsigned long size_t;
#define _SIZET
#endif

typedef long int time_t;
