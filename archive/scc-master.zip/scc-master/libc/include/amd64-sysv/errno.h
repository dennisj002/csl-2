/* See LICENSE file for copyright and license details. */
#ifndef _ERRNO_H
#define _ERRNO_H

extern int errno;

#endif
