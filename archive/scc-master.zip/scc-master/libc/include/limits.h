#ifndef _LIMITS_H
#define _LIMITS_H

#include <arch/limits.h>

#define CHAR_BIT   8
#define MB_LEN_MAX 1

#endif
