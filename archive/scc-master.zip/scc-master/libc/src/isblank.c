/* See LICENSE file for copyright and license details. */

int
isblank(int c)
{
	return (c == ' ') || (c == '\t');
}
