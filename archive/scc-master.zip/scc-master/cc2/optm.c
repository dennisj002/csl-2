
#include "../inc/cc.h"
#include "cc2.h"

Node *
optm_ind(Node *np)
{
	return np;
}

