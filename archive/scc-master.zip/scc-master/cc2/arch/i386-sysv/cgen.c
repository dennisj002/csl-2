/* See LICENSE file for copyright and license details. */
static char sccsid[] = "@(#) ./cc2/arch/i386-sysv/cgen.c";

#include "arch.h"
#include "../../../inc/cc.h"
#include "../../cc2.h"

Node *
cgen(Node *np)
{
}

Node *
sethi(Node *np)
{
}
