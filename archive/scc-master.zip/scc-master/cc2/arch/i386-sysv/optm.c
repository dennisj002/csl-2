/* See LICENSE file for copyright and license details. */
static char sccsid[] = "@(#) ./cc2/arch/i386-sysv/optm.c";

#include "../../../inc/cc.h"
#include "../../cc2.h"

Node *
optm_dep(Node *np)
{
	return np;
}
