/* See LICENSE file for copyright and license details. */
static char sccsid[] = "@(#) ./cc2/peep.c";
#include "../inc/cc.h"
#include "cc2.h"

void
peephole(void)
{
}
