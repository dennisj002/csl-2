char *sysincludes[] = {
	PREFIX "/include/scc/" ,
	PREFIX "/include/scc/bits/" ARCH "/",
	/* configure below your standard sys include paths */
	PREFIX "/include/",
	PREFIX "/local/include/",
	NULL
};
