Please use Brodie style: http://www.forth.org/forth_style.html

- Immediately after colon: 1 space
- Immediately after a defined name: 2 space
- Immediately after stack comment: 2 space (or newline)
- To indent: 3 spaces
- To separate phrases on same line: 3 spaces
