#!/usr/bin/perl

# ====================================================================
#  A simple Retro glossary formatter for Unix.
# 
#  Uses ANSI escape sequences for colour.
# ====================================================================

use strict;
use warnings;

my $process_word  = 0;
my $process_notes = 0;

my $use_colour    = 1;

# --------------------------------------------------------------------
#  Process Retro wiki glossary
# --------------------------------------------------------------------

while (<>) {
  chomp; s///g;
  next if ( /^$/ );

  if ( /^== / ) {
    s/^== //;
    red();
    print '~'x80, "\n";
    red();
    print " $_\n";
    red();
    print '~'x80, "\n\n";
    normal();
    next;
  }

  if($process_notes == 1) {
    if ( /^----$/  ) {
      $process_notes = 0;
      print "\n";
      next;
    }

    s/{{{(\S)/'$1/g;
    s/(\S)}}}/$1'/g;
    s/\s*{{{\s*//;
    s/\s*}}}\s*//;
    s/\/\//'/g;

    if ( /\(\s+[^\)]*\s+\)\s*/ ) {
      blue();
    }

    while ( length($_) > 72 ) {
      my $i = 71;
      while ( substr($_, $i, 1) ne " " ) {
        $i--;
      }
      print "\t", substr($_, 0, $i), "\n";
      $_ = substr($_, $i+1);
    }

    print "\t", $_, "\n";
    normal();
  }

  elsif ( /^----$/ ) { next; }

  elsif(/^{{{$/) {
    $process_word = 1;
    next;
  }

  elsif(/^}}}$/) {
    $process_notes = 1;
    next;
  }

  elsif ($process_word == 1) {
    green();
    print;
    print "\n";
    normal();
    $process_word = 0;
  }
}

# --------------------------------------------------------------------
#  Colours.
# --------------------------------------------------------------------

sub normal { print "[30m[0m" if ($use_colour); }
sub  green { print "[32m[1m" if ($use_colour); }
sub   blue { print "[34m[1m" if ($use_colour); }
sub    red { print "[31m[1m" if ($use_colour); }
