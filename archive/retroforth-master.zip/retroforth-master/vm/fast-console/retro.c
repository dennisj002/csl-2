//FLAGS -O3 -fomit-frame-pointer -Wall -DSOCKETS
//USES devices disassemble endian loader ngaro vm
