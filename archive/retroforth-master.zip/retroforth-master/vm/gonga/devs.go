// Original Ngaro Virtual Machine and Uki framework:
//	Copyright (C) 2008, 2009, 2010 Charles Childers
// Go port
//	Copyright 2009, 2010 JGL
// Public Domain or LICENSE file

package ngaro

import (
	"io"
	"bufio"
	"fmt"
	"net"
	"os"
	"unsafe"
	B "encoding/binary"
)

type Input struct {
	io.ReadCloser
	Next *Input
}

type Output io.Writer

var ClearScreen func() = func() {}
var ShrinkImage = false

var files = make(map[int]*os.File, 4)

type socket struct {
	listener *net.Listener
	conn     *net.Conn
	port     int
}

var sockets = make(map[int]*socket, 4)
var nsockets int

func LoadDump(filename string, size int) (img []int, err os.Error) {
	r, err := os.Open(filename, os.O_RDONLY, 0)
	if err != nil {
		return nil, err
	}
	img = make([]int, size)
	br := bufio.NewReader(r)
	var ui uint32
	var i int
	for i, _ = range img {
		if err := B.Read(br, B.LittleEndian, &ui); err != nil {
			break
		}
		img[i] = int(ui)
	}
	return img, err
}

func (vm *NgaroVM) WriteDump(filename string) os.Error {
	w, err := os.Open(filename, os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		return err
	}
	img := vm.img
	if ShrinkImage {
		img = vm.img[0:vm.img[3]]
	}
	for _, i := range img {
		if err = B.Write(w, B.LittleEndian, uint32(i)); err != nil {
			w.Close()
			break
		}
	}
	w.Close()
	return err
}

func (vm *NgaroVM) Channel(id int) chan int {
	if c, ok := vm.channel[id]; ok {
		return c
	}
	vm.channel[id] = make(chan int)
	return vm.channel[id]
}

func readA(data []int, a int) string {
	var w int
	for w = a; w < len(data) && data[w] != 0; w++ {
	}
	return string(data[a:w])
}

func (vm *NgaroVM) wait(port *[nports]int, tos, sp, rsp int, data []int) (spdec int) {
	var c [1]byte
	var err os.Error
	switch {
	case port[0] == 1:
		return

	case port[1] == 1: // Input
	readInput:
		if _, err = vm.Input.Read(c[0:]); err == os.EOF {
			vm.Input.Close()
			vm.Input = vm.Input.Next
			if vm.Input != nil {
				goto readInput
			}
		} else if err == nil {
			port[1] = int(c[0])
		}

	case port[1] > 1: // Receive from (or delete) channel
		if port[2] == port[1] {
			vm.channel[port[1]] = nil, false
			port[1] = 0
			port[2] = 0
		} else {
			port[1] = <-vm.Channel(port[1])
		}

	case port[2] == 1: // Output
		c[0] = byte(tos)
		if tos < 0 {
			ClearScreen()
		} else if _, err := vm.Output.Write(c[0:]); err == nil {
			port[2] = 0
			spdec = 1
		}

	case port[2] > 1: // Send to channel
		vm.Channel(port[2]) <- tos
		port[2] = 0
		spdec = 1

	case port[4] != 0: // Files
		switch port[4] {
		case 1: // Write dump
			vm.WriteDump(vm.dump)
		case 2: // Include file
			name := readA(vm.img, tos)
			if f, err := os.Open(name, os.O_RDONLY, 0); err == nil {
				vm.Input = &Input{f, vm.Input}
			}
		case -1: // Open file
			fname := readA(vm.img, data[sp-1])
			m := os.O_RDONLY
			switch tos {
			case 1:
				m = os.O_RDWR | os.O_CREATE
			case 2:
				m = os.O_WRONLY | os.O_APPEND | os.O_CREATE
			case 3:
				m = os.O_RDWR | os.O_CREATE
			case 4:
				m = os.O_APPEND | os.O_CREATE
			case 5:
				m = os.O_RDWR | os.O_APPEND | os.O_CREATE
			}
			f, err := os.Open(fname, m, 0666)
			if err == nil {
				h := *(*int)(unsafe.Pointer(f))
				files[h] = f
				data[sp-1] = h
			}
			spdec = 1
		case -2: // Read a byte from a file
			h := files[data[sp-1]]
			if _, err = h.Read(c[0:]); err == nil {
				vm.img[tos] = int(c[0])
			}
			spdec = 2
		case -3: // Write a byte to a file
			h := files[data[sp-1]]
			c[0] = byte(vm.img[tos])
			_, err = h.Write(c[0:])
			spdec = 2
		case -4: // Close a file
			h := files[tos]
			err = h.Close()
			spdec = 1
		case -5: // Get position in file
			h := files[tos]
			if p, err := h.Seek(0, 1); err == nil {
				port[4] = int(p)
			}
			spdec = 1
		case -6: // Set position in file
			h := files[data[sp-1]]
			_, err = h.Seek(int64(tos), 0)
			spdec = 2
		case -7: // Get file size
			h := files[data[sp-1]]
			if d, err := h.Stat(); err == nil {
				port[4] = int(d.Size)
			}
			spdec = 1
		}
		port[4] = 0

	case port[5] != 0: // Capabilities
		switch port[5] {
		case -1: // Image size
			port[5] = len(vm.img)
		case -5: // Stack depth
			port[5] = sp - 2
		case -6: // Address stack depth
			port[5] = rsp
		case -8: // Seconds from the epoch
			if t, _, err := os.Time(); err == nil {
				port[5] = int(t)
			}
		case -9: // Bye!
			vm.Err <- nil
		default:
			port[5] = 0
		}

	case port[8] != 0: // Network sockets
		switch port[8] {
		case -1: // New socket
			sockets[nsockets] = &socket{nil, nil, 0}
			data[sp] = nsockets
			nsockets++
		case -2: // Bind port to socket
			sockets[data[sp-1]].port = tos
		case -3: // Listen from socket
			a := fmt.Sprint(":", sockets[tos].port)
			if l, err := net.Listen("tcp", a); err == nil {
				(*sockets[tos]).listener = &l
			}
		case -4: // Wait for conn
			l := sockets[tos].listener
			if c, err := l.Accept(); err == nil {
				(*sockets[tos]).conn = &c
			}
		case -5: // Close socket
			l := sockets[tos].listener
			err = l.Close()
		case -6: // Write to socket
			conn := sockets[tos].conn
			s := []uint8(readA(vm.img, data[sp-1]))
			_, err = conn.Write(s)
		case -7: // Read from socket
			conn := sockets[tos].conn
			if _, err = conn.Read(c[0:]); err == nil {
				data[sp] = int(c[0])
			}
		}
		port[8] = 0

	// TODO: port[6] (canvas)
	// TODO: port[7] (mouse)

	case port[13] == 1:
		go vm.core(tos)
		port[13] = 0
		spdec = 1
	}
	if err != nil {
		panic(err)
	}
	port[0] = 1
	return
}
