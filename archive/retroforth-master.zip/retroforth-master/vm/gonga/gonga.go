// Original Ngaro Virtual Machine and Uki framework:
//	Copyright (C) 2008, 2009, 2010 Charles Childers
// Go port
//	Copyright 2009, 2010 JGL
// Public Domain or LICENSE file

package main

import (
	"./ngaro"
	"flag"
	"fmt"
	"os"
)

var Usage = func() {
	fmt.Fprint(os.Stderr, `
Gonga usage:
	gonga [options] [image file]

Gonga is the Go version of the Ngaro virtual machine.

If no image file is specified in the command line
gongaImage will be loaded, retroImage if that fails.

Options:
`)
	flag.PrintDefaults()
}

var shrink = flag.Bool("shrink", false, "shrink image dump file")
var size = flag.Int("s", 50000, "image size")
var dump = flag.String("d", "retro.img", "image dump file")

type withFiles []*os.File

func (wf *withFiles) String() string {
	return fmt.Sprint(*wf)
}

func (wf *withFiles) Set(value string) bool {
	var nwf withFiles
	if wf == nil {
		nwf = make(withFiles, 1)
	} else {
		nwf = make(withFiles, len(*wf)+1)
		copy(nwf, *wf)
	}
	if f, err := os.Open(value, os.O_RDONLY, 0666); err != nil {
		return false
	} else {
		nwf[len(nwf)-1] = f
		(*wf) = nwf
	}
	return true
}

func main() {
	var wf withFiles
	flag.Var(&wf, "w", "input files")
	flag.Usage = Usage
	flag.Parse()

	ngaro.ShrinkImage = *shrink
	ngaro.ClearScreen = func() { fmt.Printf("\033[2J\033[1;1H") }

	var img []int
	var err os.Error

	switch flag.NArg() {
	case 0:
		img, err = ngaro.LoadDump("gongaImage", *size)
		if err != nil {
			img, err = ngaro.LoadDump("retroImage", *size)
		}
	case 1:
		img, err = ngaro.LoadDump(flag.Arg(0), *size)
	default:
		fmt.Fprint(os.Stderr, "too many arguments\n")
		flag.Usage()
		os.Exit(2)
	}

	if err != nil {
		fmt.Fprint(os.Stderr, "error starting gonga: ", err.String())
		os.Exit(1)
	}

	// push os.Stdin to the bottom of the input stack
	input := &ngaro.Input{os.Stdin, nil}
	// and add "with" (-w) files
	for i, _ := range wf {
		input = &ngaro.Input{wf[len(wf)-1-i], input}
	}

	vm := ngaro.NewVM(img, *dump, input, os.Stdout)

	// <-vm.Err blocks until the vm dies
	if err = <-vm.Err; err != nil && err != os.EOF {
		fmt.Fprint(os.Stderr, "GONGA IS DEAD! "+err.String())
		os.Exit(1)
	}
}
