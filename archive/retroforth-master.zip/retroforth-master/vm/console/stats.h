/******************************************************
 * Ngaro
 * Copyright (C) 2008, 2009, Charles Childers
 ******************************************************/

#ifndef STATS_HEADER
#define STATS_HEADER

/* track how many times each opcode is run */
#define LAST_OP (NUM_OPS)
#define ILL_OP (NUM_OPS + 1)
#define TRACKED_OPS (NUM_OPS + 2)

/* track number of instructions between (potentially)
   branching ones, jumps calls and returns.  32 is
   ridiculously large actually.  Somewhere around 6-8
   there is a sharp knee. */
#define MAX_SLL (32)

/* +2: 0 1 ... if 3 is max, I am also using 4. */
/* to represent "more than 3".  And  3+2 == 5 */
#define TRACKED_SLLS (MAX_SLL + 2)

/* track how many times each literal value is used */
#define MIN_LIT (-1024)
#define MAX_LIT (8192)

/* +3: 1 for 0, 1 for below range, 1 for above range */
#define TRACKED_LITS (MAX_LIT - MIN_LIT + 3)

/* OFF_LITS + (MIN_LIT - 1) == 0 */
#define OFF_LITS (1 - MIN_LIT)

/* track how many times each jump distance is used */
#define MIN_DIST (-64)
#define MAX_DIST (2564)
#define TRACKED_DISTS (MAX_DIST - MIN_DIST + 3)
#define OFF_DISTS (1 - MIN_DIST)

/* track how deep the stacks are */
#define MIN_SP (-3)
#define MAX_SP (100)
#define TRACKED_SPS (MAX_SP - MIN_SP + 3)
#define OFF_SPS (1 - MIN_SP)

#endif
