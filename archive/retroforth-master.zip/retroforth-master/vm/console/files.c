#include <stdio.h>

#include "vm.h"
#include "functions.h"

void file_add(VM *vm) {
  char s[1024];
  int name = TOS; DROP;
  int i = 0;
  while(vm->image[name] != 0)
  {
    s[i] = (char)vm->image[name];
    i++; name++;
  }
  s[i] = 0;
  dev_include(s);
}

int file_handle(VM *vm) {
  char *modes[] = { "r", "r+", "w", "w+", "a", "a+" };
  int mode = TOS; DROP;
  int i, address = TOS; DROP;
  char filename[256];
  for (i = 0; i < 256; i++) {
    filename[i] = vm->image[address+i];
    if (! filename[i]) break;
  }
  FILE *handle = fopen(filename, modes[mode]);
  return (int)handle;
}

int file_readc(VM *vm) {
  FILE *handle = (FILE *) TOS; DROP;
  int c = fgetc(handle);
  if ( c == EOF ) {
    return 0;
  } else {
    return c;
  }
}

int file_writec(VM *vm) {
  FILE *handle = (FILE *) TOS; DROP;
  int c = TOS; DROP;
  int r = fputc(c, handle);
  if ( r == EOF ) {
    return 0;
  } else {
    return -1;
  }
}

void file_closehandle(VM *vm) {
  FILE *handle = (FILE *)TOS; DROP;
  fclose(handle);
}

int file_getpos(VM *vm) {
  FILE *handle = (FILE *)TOS; DROP;
  int pos = (int) ftell(handle);
  return pos;
}

int file_seek(VM *vm) {
  FILE *handle = (FILE *) TOS; DROP;
  int pos = TOS; DROP;
  int r = fseek(handle, pos, SEEK_SET);
  if ( r == 0 ) {
    return -1;
  } else {
    return 0;
  }
}

int file_size(VM *vm) {
  FILE *handle = (FILE *) TOS; DROP;
  int current = ftell(handle);
  int r = fseek(handle, 0, SEEK_END);
  int size = ftell(handle);
  fseek(handle, current, SEEK_SET);
  if ( r == 0 ) {
    return size;
  } else {
    return 0;
  }
}
