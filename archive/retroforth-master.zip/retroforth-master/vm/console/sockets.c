#ifdef SOCKETS
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>

#include "vm.h"

void rsocket(VM *vm)
{
  int sock;
  sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  vm->sp++;
  TOS = sock;
}

void rbind(VM *vm)
{
  struct sockaddr_in address;
  int port = TOS; DROP;
  int sock = TOS;
  address.sin_family = AF_INET;
  address.sin_addr.s_addr = INADDR_ANY;
  address.sin_port = htons(port);
  TOS = bind(sock, (struct sockaddr *)&address, sizeof(struct sockaddr));
}

void rlisten(VM *vm)
{
  int sock = TOS;
  TOS = listen(sock, 3);
}

void raccept(VM *vm)
{
  int sock = TOS;
  int addrlen;
  struct sockaddr_in address;
  addrlen = sizeof(struct sockaddr_in);
  TOS = accept(sock, (struct sockaddr *)&address, (socklen_t *)&addrlen);
}

void rclose(VM *vm)
{
  int sock = TOS;
  shutdown(sock, SHUT_RDWR);
  TOS = close(sock);
}

void rsend(VM *vm)
{
  int sock = TOS; DROP;
  int data = TOS;
  char s[65535];
  int  c;
  for (c = 0; c < 65535; c++)
    s[c] = '\0';
  for (c = 0; vm->image[data] != 0; c++, data++)
    s[c] = (char)vm->image[data];
  TOS = send(sock, s, strlen(s), 0);
}

void rrecv(VM *vm)
{
  int sock = TOS;
  char s[2] = { 0, 0 };
  recv(sock, s, 1, 0);
  TOS = (int)s[0];
}

void rconnect(VM *vm)
{
  int sock = TOS; DROP;
  int port = TOS; DROP;
  int data = TOS;
  struct sockaddr_in address;
  struct hostent *server;
  char s[1024];
  int c, addrlen;

  addrlen = sizeof(struct sockaddr_in);

  for (c = 0; c < 1024; c++)
    s[c] = '\0';
  for (c = 0; vm->image[data] != 0; c++, data++)
    s[c] = (char)vm->image[data];

  server = gethostbyname(s);

  bzero((char *) &address, sizeof(address));
  address.sin_family = AF_INET;
  bcopy((char *)server->h_addr, (char *)&address.sin_addr.s_addr, server->h_length);
  address.sin_port = htons(port);

  TOS = connect(sock, (struct sockaddr *)&address, (socklen_t)addrlen);
}
#endif
