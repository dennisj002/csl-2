# echo "Clashes: "

./retro --with hash-test.retro | grep -v "^ok"  | grep "^|-" |
  awk '{ print $3 }' | sort -n | uniq -c | sort -n  | grep -v "^ *1 "
