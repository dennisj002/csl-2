#ifndef __PTRHASH_H_
#define __PTRHASH_H_

#include "htableh.inc"

HTPROT(ptrhash)

#endif
