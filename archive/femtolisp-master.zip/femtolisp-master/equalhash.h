#ifndef EQUALHASH_H
#define EQUALHASH_H

#include "htableh.inc"

HTPROT(equalhash)

#endif
