# README

[chao-dyn/9404003v1] The Limits of Mathematics (in C)
G.J. Chaitin (IBM Research Division)
https://arxiv.org/abs/chao-dyn/9404003v1

