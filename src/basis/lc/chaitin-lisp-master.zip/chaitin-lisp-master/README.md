chaitin-lisp
============

Toying with a port of Chaitin's LISP
